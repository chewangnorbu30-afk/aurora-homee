package com.example.tvlauncher

import android.content.Context
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

fun Context.dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

fun View.roundCorners(radiusPx: Float) {
    outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, radiusPx)
        }
    }
    clipToOutline = true
}

/** One app tile: rounded card with banner/icon, white focus ring, label that fades in. */
class TileView(context: Context) : LinearLayout(context) {
    private val image = ImageView(context)
    private val ring = View(context)
    private val label = TextView(context)

    init {
        orientation = LinearLayout.VERTICAL
        isFocusable = true
        isClickable = true
        clipChildren = false
        clipToPadding = false

        val radius = context.dp(20).toFloat()
        val card = FrameLayout(context)
        card.background = GradientDrawable().apply {
            cornerRadius = radius
            setColor(Color.parseColor("#262630"))
        }
        card.roundCorners(radius)

        card.addView(
            image,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        ring.background = GradientDrawable().apply {
            cornerRadius = radius
            setStroke(context.dp(3), Color.WHITE)
            setColor(Color.TRANSPARENT)
        }
        ring.alpha = 0f
        card.addView(
            ring,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        addView(card, LinearLayout.LayoutParams(context.dp(208), context.dp(117)))

        label.setTextColor(Color.WHITE)
        label.textSize = 16f
        label.gravity = Gravity.CENTER_HORIZONTAL
        label.maxLines = 1
        label.ellipsize = TextUtils.TruncateAt.END
        label.alpha = 0f
        val lp = LinearLayout.LayoutParams(context.dp(208), ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = context.dp(12)
        addView(label, lp)
    }

    fun bind(e: AppEntry) {
        label.text = e.label
        val banner = e.banner
        if (banner != null) {
            image.setPadding(0, 0, 0, 0)
            image.scaleType = ImageView.ScaleType.CENTER_CROP
            image.setImageDrawable(banner)
        } else {
            val p = context.dp(30)
            image.setPadding(p, p, p, p)
            image.scaleType = ImageView.ScaleType.CENTER_INSIDE
            image.setImageDrawable(e.icon)
        }
    }

    fun setHighlighted(on: Boolean) {
        val s = if (on) 1.14f else 1f
        animate()
            .scaleX(s)
            .scaleY(s)
            .translationY(if (on) -context.dp(6).toFloat() else 0f)
            .translationZ(if (on) 10f else 0f)
            .setDuration(180)
            .setInterpolator(DecelerateInterpolator())
            .start()
        ring.animate().alpha(if (on) 1f else 0f).setDuration(180).start()
        label.animate().alpha(if (on) 1f else 0f).setDuration(180).start()
    }
}

class AppAdapter(
    private val onFocused: (AppEntry, View) -> Unit,
    private val onOpen: (AppEntry) -> Unit,
    private val onInfo: (AppEntry) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    private var items: List<AppEntry> = emptyList()

    class VH(val tile: TileView) : RecyclerView.ViewHolder(tile)

    fun submit(list: List<AppEntry>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val tile = TileView(parent.context)
        tile.layoutParams = RecyclerView.LayoutParams(
            RecyclerView.LayoutParams.WRAP_CONTENT,
            RecyclerView.LayoutParams.WRAP_CONTENT
        )
        return VH(tile)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val entry = items[position]
        val tile = holder.tile
        tile.bind(entry)
        tile.setHighlighted(false)
        tile.setOnClickListener { onOpen(entry) }
        tile.setOnLongClickListener {
            onInfo(entry)
            true
        }
        tile.setOnFocusChangeListener { v, hasFocus ->
            tile.setHighlighted(hasFocus)
            if (hasFocus) onFocused(entry, v)
        }
    }

    override fun getItemCount(): Int = items.size
}
