package com.example.tvlauncher

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private lateinit var hero: View
    private lateinit var heroContent: View
    private lateinit var heroTitle: TextView
    private lateinit var heroSub: TextView
    private lateinit var heroImage: ImageView
    private lateinit var row: RecyclerView
    private lateinit var adapter: AppAdapter

    private val worker = Executors.newSingleThreadExecutor()
    private var current: AppEntry? = null
    private var firstLoad = true
    private var shownKeys: List<String> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        hero = findViewById(R.id.hero)
        heroContent = findViewById(R.id.heroContent)
        heroTitle = findViewById(R.id.heroTitle)
        heroSub = findViewById(R.id.heroSub)
        heroImage = findViewById(R.id.heroImage)
        row = findViewById(R.id.row)

        heroImage.roundCorners(dp(20).toFloat())
        heroImage.background = GradientDrawable().apply {
            cornerRadius = dp(20).toFloat()
            setColor(Color.parseColor("#2A2A35"))
        }

        // Keep the featured image 16:9 and sized to the hero card on any resolution.
        hero.addOnLayoutChangeListener { v, _, _, _, _, _, _, _, _ ->
            val h = v.height - dp(48)
            val w = h * 16 / 9
            val lp = heroImage.layoutParams
            if (h > 0 && (lp.height != h || lp.width != w)) {
                lp.height = h
                lp.width = w
                heroImage.post { heroImage.layoutParams = lp }
            }
        }

        hero.setOnClickListener { current?.let { open(it) } }
        hero.setOnLongClickListener {
            current?.let { info(it) }
            true
        }
        hero.setOnFocusChangeListener { v, hasFocus ->
            val s = if (hasFocus) 1.02f else 1f
            v.animate().scaleX(s).scaleY(s).setDuration(180).start()
        }

        adapter = AppAdapter(
            onFocused = { entry, view ->
                showFeatured(entry)
                centerOn(view)
            },
            onOpen = { open(it) },
            onInfo = { info(it) }
        )
        row.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
        row.adapter = adapter
        row.addItemDecoration(object : RecyclerView.ItemDecoration() {
            override fun getItemOffsets(
                outRect: android.graphics.Rect,
                view: View,
                parent: RecyclerView,
                state: RecyclerView.State
            ) {
                outRect.right = dp(28)
            }
        })
    }

    override fun onResume() {
        super.onResume()
        loadApps()
    }

    override fun onDestroy() {
        worker.shutdown()
        super.onDestroy()
    }

    private fun loadApps() {
        worker.execute {
            val list = AppRepository.load(this)
            val keys = list.map { it.packageName }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (keys != shownKeys) {
                    shownKeys = keys
                    adapter.submit(list)
                    val stillThere = current?.packageName?.let { keys.contains(it) } ?: false
                    if (!stillThere) {
                        list.firstOrNull()?.let { showFeatured(it, animate = false) }
                    }
                }
                if (firstLoad && list.isNotEmpty()) {
                    firstLoad = false
                    row.post {
                        row.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus()
                    }
                }
            }
        }
    }

    private fun centerOn(v: View) {
        val dx = (v.left + v.width / 2) - (row.width / 2)
        if (dx != 0) row.smoothScrollBy(dx, 0)
    }

    private fun showFeatured(e: AppEntry, animate: Boolean = true) {
        if (current?.packageName == e.packageName && heroTitle.text.isNotEmpty()) return
        current = e
        if (!animate) {
            applyHero()
            return
        }
        heroContent.animate().cancel()
        heroContent.animate()
            .alpha(0f)
            .setDuration(90)
            .withEndAction {
                applyHero()
                heroContent.animate().alpha(1f).setDuration(160).start()
            }
            .start()
    }

    private fun applyHero() {
        val e = current ?: return
        heroTitle.text = e.label
        heroSub.text =
            if (e.isSettings) "Press OK to open Settings"
            else "Press OK to open  \u00B7  Hold OK for app info"

        val source = e.banner ?: e.icon
        val copy = source?.constantState?.newDrawable()?.mutate() ?: source
        if (e.banner != null) {
            heroImage.setPadding(0, 0, 0, 0)
            heroImage.scaleType = ImageView.ScaleType.CENTER_CROP
        } else {
            val p = dp(36)
            heroImage.setPadding(p, p, p, p)
            heroImage.scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        heroImage.setImageDrawable(copy)
    }

    private fun open(e: AppEntry) {
        try {
            startActivity(e.intent)
        } catch (ex: Exception) {
            Toast.makeText(this, "Couldn't open ${e.label}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun info(e: AppEntry) {
        if (e.isSettings) return
        try {
            val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${e.packageName}"))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (ex: Exception) {
            Toast.makeText(this, "App info isn't available", Toast.LENGTH_SHORT).show()
        }
    }
}
