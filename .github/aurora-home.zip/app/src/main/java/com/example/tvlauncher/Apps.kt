package com.example.tvlauncher

import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.provider.Settings

class AppEntry(
    val label: String,
    val packageName: String,
    val intent: Intent,
    val banner: Drawable?,
    val icon: Drawable?
) {
    val isSettings: Boolean get() = packageName == AppRepository.SETTINGS_ID
}

object AppRepository {
    const val SETTINGS_ID = "aurora.settings"

    // Shown first, in this order, when installed. Everything else follows A-Z.
    private val favorites = listOf(
        "com.google.android.youtube.tv",
        "com.netflix.ninja",
        "com.amazon.amazonvideo.livingroom",
        "com.disney.disneyplus",
        "com.apple.atve.androidtv.appletv",
        "com.wbd.stream",
        "com.hulu.livingroomplus",
        "com.spotify.tv.android",
        "com.plexapp.android"
    )

    private fun rank(pkg: String): Int {
        val i = favorites.indexOf(pkg)
        return if (i < 0) Int.MAX_VALUE else i
    }

    fun load(context: Context): List<AppEntry> {
        val pm = context.packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val found = LinkedHashMap<String, AppEntry>()

        for (ri in pm.queryIntentActivities(query, 0)) {
            val info = ri.activityInfo ?: continue
            val pkg = info.packageName
            if (pkg == context.packageName || found.containsKey(pkg)) continue

            val launch = Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
                .setClassName(pkg, info.name)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)

            val banner: Drawable? = try {
                info.loadBanner(pm) ?: info.applicationInfo.loadBanner(pm)
            } catch (e: Exception) {
                null
            }
            val icon: Drawable? = try {
                ri.loadIcon(pm)
            } catch (e: Exception) {
                null
            }
            found[pkg] = AppEntry(ri.loadLabel(pm).toString(), pkg, launch, banner, icon)
        }

        val sorted = found.values.sortedWith(
            compareBy<AppEntry>({ rank(it.packageName) }, { it.label.lowercase() })
        )

        val settingsIntent = Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val settings = AppEntry(
            "Settings",
            SETTINGS_ID,
            settingsIntent,
            null,
            context.getDrawable(R.drawable.ic_settings)
        )
        return sorted + settings
    }
}
